<?php
get_header();

get_template_part('template-parts/packs/file', 'homepage');

get_footer();
